package fruitstore;

public interface DiscountProvider {
	 abstract public double applyDiscount();

}
