package fruitstore;

public interface CustomerRegistration {
    abstract public int registerCustomer(int id,String password);
}
